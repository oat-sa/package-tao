//evaluates the users answer

var goodAnswer = function () {
	// Approve the answer.
	setEndorsment(true);
	
	// Give an appropriate score.
	setScore(1);
	
	// Alert TAO that the taking of this item is finished.
	finish();
}

var badAnswer = function () {
	// Approve the answer.
	setEndorsment(false);
	
	// Give an appropriate score.
	setScore(0);
	
	// Alert TAO that the taking of this item is finished.
	finish();
};
