var api;

window.onItemApiReady = function(itemApi){
    $('#correct').bind('click', submitCorrect);
    $('#wrong').bind('click', submitWrong);
    api = itemApi;
}

function submitCorrect (e) {
    api.saveResponses({'response' : 'correct'});
    api.saveScores({'score': 1});
    api.finish();
}

function submitWrong (e) {
    api.saveResponses({'response' : 'wrong'});
    api.saveScores({'score': 0});
    api.finish();
}
